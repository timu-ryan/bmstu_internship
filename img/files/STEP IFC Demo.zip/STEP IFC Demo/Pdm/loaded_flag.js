﻿// Задание флага loaded для control
function set_loaded ( sCtrlID )
{
	ctrl = document.getElementById ( sCtrlID ) ;
	if ( ctrl == null )
	{
		alert ( 'set_loaded: неизвестное имя control:' + sCtrlID ) ;
		return ;
	}
	ctrl.setAttribute ( "loaded", "1" ) ;
}
// Проверка флага loaded для control
function is_loaded ( sCtrlID )
{
	ctrl = document.getElementById ( sCtrlID ) ;
	if ( ctrl == null )
	{
		alert ( 'is_loaded: неизвестное имя control:' + sCtrlID ) ;
		return ;
	}
	return ctrl.getAttribute ( "loaded" ) == "1" ;
}

////	Тесты
//set_loaded ( "products1" ) ;
//set_loaded ( "products" ) ;
//if ( is_loaded ( "products" ) )
//	alert ( 'yes' ) ;
//else
//	alert ( 'no !!!' ) ;
