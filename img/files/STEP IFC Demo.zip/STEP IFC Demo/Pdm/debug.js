﻿//	Вывод отладочного сообщения в debug control
function TRACE ( sMessage )
{
	debug.innerHTML = sMessage ;
}

