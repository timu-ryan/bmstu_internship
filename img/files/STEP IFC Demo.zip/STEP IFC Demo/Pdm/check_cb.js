﻿function fnIsOurCustomBrowser()
{
	//Check to see if this is our custom
	//browser. We just see if the function 
	//IsOurCustomBrowser is available. By leaving
	//the brackets off of our function it is treated
	//as a property and thus allows us to check if
	//our method exists in the external window. If it
	//returns null then obviously this is not our custom
	//browser, so we return false.
	if(window.external.CB_IsOurCustomBrowser!=null)
		return true;
	else 
		return false;
}	

//	Проверка использования CustomBrowser
function NotCustomBrowser ()
{
	if ( ! bIsCustomBrowser )
	{
		alert('You must be using Custom Browser to view this page properly.');
		return true ;
	}
	return false ;
}

//setup a variable to let us know if this is our
//custom browser.
bIsCustomBrowser = fnIsOurCustomBrowser();

if(!bIsCustomBrowser)
{
	//You can check here to see if they have our custom browser.
	//If they don't you can do whatever you want, redirect them
	//to another page or whatever. For the purposes of this example
	//I will just alert them
	alert('You must be using Custom Browser to view this page properly.');
}
